---
title: Gatsby on Netlify
date: "2015-12-14T22:12:03.284Z"
layout: post
readNext: "/hi-folks/"
path: "/netlify/"
---

This is how easy it is to start a new blog built with Gatsby and host it on Netlify.