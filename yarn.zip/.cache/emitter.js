"use strict";

var _mitt = require("mitt");

var _mitt2 = _interopRequireDefault(_mitt);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var emitter = (0, _mitt2.default)();
module.exports = emitter;
//# sourceMappingURL=emitter.js.map